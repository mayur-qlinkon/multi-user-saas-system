<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreQuotationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // Assuming role/permission middleware handles access
    }

    public function rules(): array
    {
        return [
            // Core Identity
            'store_id' => ['required', 'exists:stores,id'],
            'customer_id' => ['nullable', 'exists:clients,id'],

            // Customer Snapshots
            'customer_name' => ['nullable', 'string', 'max:255', 'required_without:customer_id'],
            'customer_phone' => ['nullable', 'string', 'max:20'],
            'customer_email' => ['nullable', 'email', 'max:255'],
            'customer_gstin' => ['nullable', 'string', 'max:50'],
            'billing_address' => ['nullable', 'array'],
            'shipping_address' => ['nullable', 'array'],

            // References & Dates
            'reference_number' => ['nullable', 'string', 'max:100'],
            'quotation_date' => ['required', 'date'],
            'valid_until' => ['nullable', 'date', 'after_or_equal:quotation_date'],

            // Config & Taxes
            'currency_code' => ['nullable', 'string', 'max:3'],
            'exchange_rate' => ['nullable', 'numeric', 'min:0.0001'],
            'supply_state' => ['nullable', 'string', 'max:100'],
            'gst_treatment' => ['required', Rule::in(['registered', 'unregistered', 'composition', 'overseas', 'sez'])],

            // Global Financials
            'discount_type' => ['required', Rule::in(['fixed', 'percentage'])],
            'discount_amount' => ['nullable', 'numeric', 'min:0'],
            'shipping_charge' => ['nullable', 'numeric', 'min:0'],
            'other_charges' => ['nullable', 'numeric', 'min:0'],

            // Notes
            'notes' => ['nullable', 'string'],
            'terms_conditions' => ['nullable', 'string'],

            // ─────────────────────────────────────────────────────────
            // LINE ITEMS VALIDATION
            // ─────────────────────────────────────────────────────────
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_id' => ['nullable', 'exists:products,id'],
            'items.*.product_sku_id' => ['nullable', 'exists:product_skus,id'],
            'items.*.unit_id' => ['nullable', 'exists:units,id'],

            // Line Item Snapshots
            'items.*.product_name' => ['required', 'string', 'max:255'],
            'items.*.sku_code' => ['nullable', 'string', 'max:100'],
            'items.*.hsn_code' => ['nullable', 'string', 'max:50'],

            // Line Item Math
            'items.*.quantity' => ['required', 'numeric', 'min:0.01'],
            'items.*.unit_price' => ['required', 'numeric', 'min:0'],
            'items.*.tax_type' => ['required', Rule::in(['inclusive', 'exclusive'])],
            'items.*.tax_percent' => ['required', 'numeric', 'min:0', 'max:100'],
            'items.*.discount_type' => ['required', Rule::in(['fixed', 'percentage'])],
            'items.*.discount_amount' => ['nullable', 'numeric', 'min:0'],
        ];
    }

    public function messages(): array
    {
        return [
            'items.required' => 'You must add at least one item to the quotation.',
            'customer_name.required_without' => 'Please provide a customer name if no existing client is selected.',
        ];
    }
}
